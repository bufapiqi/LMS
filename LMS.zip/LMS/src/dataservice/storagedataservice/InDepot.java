package dataservice.storagedataservice;

import po.storagePO.DepotPO;

public interface InDepot {
	
	
	public void inDepot(DepotPO depo);
	
	
}

package dataservice.storagedataservice;

import po.storagePO.DepotPO;

public interface GetDepot {
	
	public DepotPO getDepot();
	
}

package presentation.icwarehousemanui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import presentation.mainui.mainui;

public class icwarehousemanui extends JFrame{
	private JLabel warnJLabel;
	private String[] args;
	private JButton outjButton;
	private icwarehousemanJpanel icwarehousemanJpanel;
	private icwarehousemanOperationJpanel operationJpanel;
	private JButton b1,b2,b3,b4,b5,b6;
	public icwarehousemanui(String s,String [] args) {
		// TODO Auto-generated constructor stub
		super(s);
		this.args=args;
		init();
		registListener(this);
	}
	private void init(){
		icwarehousemanJpanel=new icwarehousemanJpanel();
		operationJpanel=new icwarehousemanOperationJpanel();
		warnJLabel=new JLabel();
		warnJLabel.setOpaque(true);
		//��汨�����������ӷ����ı�
		warnJLabel.setBackground(Color.GREEN);
		b1=new JButton("����");
		b2=new JButton("���");
		b3=new JButton("����ѯ");
		b4=new JButton("����̵�");
		b5=new JButton("����������");
		b6=new JButton("����ʼ��");
		b1.setForeground(Color.RED);
		b2.setForeground(Color.RED);
		b3.setForeground(Color.RED);
		b4.setForeground(Color.RED);
		b5.setForeground(Color.RED);
		b6.setForeground(Color.RED);
		operationJpanel.setBounds(260, 30, 730,650);
		b1.setFont(new Font("�����п�",Font.BOLD, 24));
		b2.setFont(new Font("�����п�",Font.BOLD, 24));
		b3.setFont(new Font("�����п�",Font.BOLD, 24));
		b4.setFont(new Font("�����п�",Font.BOLD, 24));
		b5.setFont(new Font("�����п�",Font.BOLD, 24));
		b6.setFont(new Font("�����п�",Font.BOLD, 24));
		b1.setBounds(30,100,200, 50);
		b2.setBounds(30,190,200, 50);
		b3.setBounds(30, 280,200, 50);
		b4.setBounds(30, 370,200, 50);
		b5.setBounds(30,460 , 200, 50);
		b6.setBounds(30, 550, 200, 50);
		warnJLabel.setBounds(120,50, 30, 30);
		ImageIcon outIcon=new ImageIcon("picture/�˳���¼.png");
		outjButton=new JButton(outIcon);
		outjButton.setBounds(50, 620,  48,48);
		outjButton.setContentAreaFilled(false);
		 icwarehousemanJpanel.add(warnJLabel);
		 icwarehousemanJpanel.add(outjButton);
		icwarehousemanJpanel.add(b1);
		icwarehousemanJpanel.add(b2);
		icwarehousemanJpanel.add(b3);
		icwarehousemanJpanel.add(b4);
		icwarehousemanJpanel.add(b5);
		icwarehousemanJpanel.add(b6);
		icwarehousemanJpanel.add(operationJpanel);
		icwarehousemanJpanel.setLayout(null);
		operationJpanel.setOpaque(false);
		this.add(icwarehousemanJpanel);
		this.setSize( 1024, 730);
		//����
		Toolkit kitToolkit =Toolkit.getDefaultToolkit();
		Dimension screenSize=kitToolkit.getScreenSize();
		int screenWidth=screenSize.width;
		int screenHeight=screenSize.height;
		int windowWidth=this.getWidth();
		int windowHeight=this.getHeight();
		this.setLocation((screenWidth-windowWidth)/2, (screenHeight-windowHeight)/2);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//���������ڸı��С
		this.setResizable(false);
		this.setVisible(true);
	}
	private void registListener(final icwarehousemanui icwarehousemanui){
		outjButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				new mainui().main(args);
				icwarehousemanui.dispose();
			}
		});
	}
}
class icwarehousemanJpanel extends JPanel{
	private ImageIcon backgroundIcon=new ImageIcon("picture/����.png");
	public void paintComponent(Graphics g)  
	{  
	    super.paintComponent(g);    
	    g.drawImage(backgroundIcon.getImage(),0,0,null);
     }
   }
class icwarehousemanOperationJpanel extends JPanel{
	private ImageIcon frameIcon =new ImageIcon("picture/�������.png");
	public void paintComponent(Graphics g)  
	{  
	    super.paintComponent(g);    
	    g.drawImage(frameIcon.getImage(),-7,-12,null);
     }
}
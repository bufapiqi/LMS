package presentation.financialstaffui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class b2financialstaffui extends JFrame{
	private financialstaffJpanel financialstaffJpanel;
	private financialstaffOperationJpanel operationJpanel;
	private JButton addaccountButton;
	private JButton returnButton;
	public b2financialstaffui(String s,financialstaffui fsui) {
		// TODO Auto-generated constructor stub
		super(s);
		init();
		registListener(fsui, this);
	}
	private void init(){
		financialstaffJpanel=new financialstaffJpanel();
		operationJpanel=new financialstaffOperationJpanel();
		addaccountButton=new JButton("�½��˻�");
		ImageIcon returnIcon=new ImageIcon("picture/����.png");
		returnButton=new JButton(returnIcon);
		returnButton.setBounds(662, 575,48,48);
		returnButton.setContentAreaFilled(false);
		operationJpanel.setBounds(260, 30, 730,650);
		addaccountButton.setForeground(Color.RED);
		addaccountButton.setFont(new Font("�����п�",Font.BOLD, 24));
		addaccountButton.setBounds(30, 200,200, 50);

		operationJpanel.add(returnButton);
		financialstaffJpanel.add(addaccountButton);
		financialstaffJpanel.add(operationJpanel);
		operationJpanel.setLayout(null);
		financialstaffJpanel.setLayout(null);
		operationJpanel.setOpaque(false);
		this.add(financialstaffJpanel);
		this.setSize( 1024, 730);
		//����
		Toolkit kitToolkit =Toolkit.getDefaultToolkit();
		Dimension screenSize=kitToolkit.getScreenSize();
		int screenWidth=screenSize.width;
		int screenHeight=screenSize.height;
		int windowWidth=this.getWidth();
		int windowHeight=this.getHeight();
		this.setLocation((screenWidth-windowWidth)/2, (screenHeight-windowHeight)/2);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//���������ڸı��С
		this.setResizable(false);
		this.setVisible(true);
	}
	private void registListener(final financialstaffui fsui,final b2financialstaffui b2fsui){
		returnButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				fsui.setVisible(true);
				b2fsui.dispose();
				
			}
		});
	}
}
package presentation.senderui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

import presentation.mainui.mainui;

public class senderui extends JFrame{
	private String[] args;
	private senderJpanel senderJpanel;
	private senderOperationJpanel operationJpanel;
	private JLabel informationJLabel;
	private JButton returnjButton;
	public senderui(String s,String[] args) {
		// TODO Auto-generated constructor stub
		super(s);
		this.args=args;	
		init();
		registerLister(this);
	}
	private void init(){
		senderJpanel=new senderJpanel();
		operationJpanel=new senderOperationJpanel();
		informationJLabel=new JLabel("������Ϣ");
		operationJpanel.setBounds(260, 30, 730,650);
		ImageIcon returnIcon=new ImageIcon("picture/����.png");
		returnjButton=new JButton(returnIcon);
		returnjButton.setBounds(662, 575, 48,48);
		returnjButton.setContentAreaFilled(false);
		operationJpanel.setLayout(null);
		operationJpanel.add(returnjButton);
		informationJLabel.setFont(new Font("��Բ",Font.BOLD, 36));
		informationJLabel.setBounds(30, 100, 200, 50);
		informationJLabel.setForeground(Color.white);
		senderJpanel.add(informationJLabel);
		senderJpanel.add(operationJpanel);
		senderJpanel.setLayout(null);
		operationJpanel.setOpaque(false);
		this.add(senderJpanel);
		this.setSize( 1024, 730);
		//����
		Toolkit kitToolkit =Toolkit.getDefaultToolkit();
		Dimension screenSize=kitToolkit.getScreenSize();
		int screenWidth=screenSize.width;
		int screenHeight=screenSize.height;
		int windowWidth=this.getWidth();
		int windowHeight=this.getHeight();
		this.setLocation((screenWidth-windowWidth)/2, (screenHeight-windowHeight)/2);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//���������ڸı��С
		this.setResizable(false);
		this.setVisible(true);
	}
	private void registerLister(final senderui s){
		returnjButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
				new mainui().main(args);
				s.dispose();
			}
		});
	
	}
}
class senderJpanel extends JPanel{
	private ImageIcon backgroundIcon=new ImageIcon("picture/����.png");
	public void paintComponent(Graphics g)  
	{  
	    super.paintComponent(g);    
	    g.drawImage(backgroundIcon.getImage(),0,0,null);
     }
   }
class senderOperationJpanel extends JPanel{
	private ImageIcon frameIcon =new ImageIcon("picture/�������.png");
	public void paintComponent(Graphics g)  
	{  
	    super.paintComponent(g);    
	    g.drawImage(frameIcon.getImage(),-7,-12,null);
     }
}
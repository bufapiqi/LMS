package presentation.courierui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import presentation.mainui.mainui;

public class courierui extends JFrame{
	private String[] args;
	private JButton outjButton;
		private JButton orderfoundButton;
  		private JButton orderfinishButton;
  		private courierJpanel courierJpanel;
  		private courierOperationJpanel operationJpanel;
  		public courierui(String s,String[] args) {
	// TODO Auto-generated constructor stub
  		super(s);
  		this.args=args;
		init();
		registListener(this);
}
 private void init(){
	 	ImageIcon orderfoundIcon=new ImageIcon("picture/�ļ�������.png");
	 	ImageIcon orderfinishIcon=new ImageIcon("picture/�ռ�������.png");
	 	orderfinishButton=new JButton(orderfinishIcon);
	 	orderfoundButton=new JButton(orderfoundIcon);
	 	orderfinishButton.setContentAreaFilled(false);
	 	orderfoundButton.setContentAreaFilled(false);
	 	courierJpanel=new courierJpanel();
	 	operationJpanel=new courierOperationJpanel();
	 	operationJpanel.setBounds(260, 30, 730,650);
	 	orderfoundButton.setBounds(30, 200, 200, 50);
	 	orderfinishButton.setBounds(30, 400, 200, 50);

	 	ImageIcon outIcon=new ImageIcon("picture/�˳���¼.png");
		outjButton=new JButton(outIcon);
		outjButton.setBounds(50, 620,  48,48);
		outjButton.setContentAreaFilled(false);
		 courierJpanel.add(outjButton);
	 	courierJpanel.add(orderfinishButton);
	 	courierJpanel.add(orderfoundButton);
	 	courierJpanel.add(operationJpanel);
	 	courierJpanel.setLayout(null);
	 	operationJpanel.setOpaque(false);
	 	this.add(courierJpanel);
	 	this.setSize( 1024, 730);
		//����
		Toolkit kitToolkit =Toolkit.getDefaultToolkit();
		Dimension screenSize=kitToolkit.getScreenSize();
		int screenWidth=screenSize.width;
		int screenHeight=screenSize.height;
		int windowWidth=this.getWidth();
		int windowHeight=this.getHeight();
		this.setLocation((screenWidth-windowWidth)/2, (screenHeight-windowHeight)/2);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//���������ڸı��С
		this.setResizable(false);
		this.setVisible(true);
		
}
	private void registListener(final courierui courierui){
		outjButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
	
				new mainui().main(args);
				courierui.dispose();
			}
		});
	}
}
class courierJpanel extends JPanel{
		private ImageIcon backgroundIcon=new ImageIcon("picture/����.png");
		public void paintComponent(Graphics g)  
		{  
			super.paintComponent(g);    
			g.drawImage(backgroundIcon.getImage(),0,0,null);
		}
   }
class courierOperationJpanel extends JPanel{
		private ImageIcon frameIcon =new ImageIcon("picture/�������.png");
		public void paintComponent(Graphics g)  
	{  
			super.paintComponent(g);    
			g.drawImage(frameIcon.getImage(),-7,-12,null);
     }
}

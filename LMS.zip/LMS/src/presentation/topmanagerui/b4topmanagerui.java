package presentation.topmanagerui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class b4topmanagerui extends JFrame{
		private topmanagerJpanel topmanagerJpanel;
		private topmanagerOperationJpanel operationJpanel;
		private JButton b1,b2;
		private JButton returnButton;
		public b4topmanagerui(String s,topmanagerui tmui) {
			// TODO Auto-generated constructor stub
			super(s);
			init();
			registListener(tmui, this);
		}
		private void init(){
			topmanagerJpanel=new topmanagerJpanel();
			operationJpanel=new topmanagerOperationJpanel();
			b1=new JButton("��Ӫ�������");
			b2=new JButton("�ɱ���������");
			ImageIcon returnIcon=new ImageIcon("picture/����.png");
			returnButton=new JButton(returnIcon);
			returnButton.setBounds(662, 575, 48,48);
			returnButton.setContentAreaFilled(false);
			operationJpanel.setBounds(260, 30, 730,650);
			b1.setForeground(Color.RED);
			b2.setForeground(Color.RED);
			b1.setFont(new Font("�����п�",Font.BOLD, 24));
			b2.setFont(new Font("�����п�",Font.BOLD, 24));
			b1.setBounds(30, 200,200, 50);
			b2.setBounds(30, 400,200, 50);
			operationJpanel.add(returnButton);
			topmanagerJpanel.add(b1);
			topmanagerJpanel.add(b2);
			topmanagerJpanel.add(operationJpanel);
			operationJpanel.setLayout(null);
			topmanagerJpanel.setLayout(null);
			operationJpanel.setOpaque(false);
			this.add(topmanagerJpanel);
			this.setSize( 1024, 730);
			//����
			Toolkit kitToolkit =Toolkit.getDefaultToolkit();
			Dimension screenSize=kitToolkit.getScreenSize();
			int screenWidth=screenSize.width;
			int screenHeight=screenSize.height;
			int windowWidth=this.getWidth();
			int windowHeight=this.getHeight();
			this.setLocation((screenWidth-windowWidth)/2, (screenHeight-windowHeight)/2);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			//���������ڸı��С
			this.setResizable(false);
			this.setVisible(true);
		}
		private void registListener(final topmanagerui tmui,final b4topmanagerui b4tmui){
			returnButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					tmui.setVisible(true);
					b4tmui.dispose();
					
				}
			});
		}
}

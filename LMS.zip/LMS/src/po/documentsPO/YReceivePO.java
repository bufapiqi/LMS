package po.documentsPO;

import java.io.Serializable;

import businesslogic.state.CargoState;

public class YReceivePO extends DocumentPO implements Serializable {
	private String date;//��������
	private String code;//���յ����
	private String doName;//������
	private String departure;//������
	private CargoState state;//����״̬
	public YReceivePO(String date, String code, String doName,
			String departure, CargoState state) {
		super();
		this.date = date;
		this.code = code;
		this.doName = doName;
		this.departure = departure;
		this.state = state;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDoName() {
		return doName;
	}
	public void setDoName(String doName) {
		this.doName = doName;
	}
	public String getDeparture() {
		return departure;
	}
	public void setDeparture(String departure) {
		this.departure = departure;
	}
	public CargoState getState() {
		return state;
	}
	public void setState(CargoState state) {
		this.state = state;
	}
	
	
	
	
}

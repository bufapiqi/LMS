package po.documentsPO;

import java.io.Serializable;

public class PaymentPO extends DocumentPO implements Serializable {
	private String code;//������
	private String doName;//������
	private String date;
	private double fund;//������
	private String name;//����������
	private String account;//�����˺�
	private String type;//��Ŀ
	private String remark;//��ע
	public PaymentPO(String code, String doName, String date, double fund,
			String name, String account, String type, String remark) {
		super();
		this.code = code;
		this.doName = doName;
		this.date = date;
		this.fund = fund;
		this.name = name;
		this.account = account;
		this.type = type;
		this.remark = remark;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDoName() {
		return doName;
	}
	public void setDoName(String doName) {
		this.doName = doName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getFund() {
		return fund;
	}
	public void setFund(double fund) {
		this.fund = fund;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	

	
}

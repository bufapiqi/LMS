package po.documentsPO;

import java.io.Serializable;

public class GetOrderPO extends DocumentPO implements Serializable {
	private String code;//�ռ������
	private String doName;//������
	private String ReceiverName;//�ռ�������
	private String date;//�ռ�����
	public GetOrderPO(String code, String doName, String receiverName,
			String date) {
		super();
		this.code = code;
		this.doName = doName;
		ReceiverName = receiverName;
		this.date = date;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDoName() {
		return doName;
	}
	public void setDoName(String doName) {
		this.doName = doName;
	}
	public String getReceiverName() {
		return ReceiverName;
	}
	public void setReceiverName(String receiverName) {
		ReceiverName = receiverName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
}

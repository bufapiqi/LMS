package businesslogic.state;

public enum ResultMessage {
	SUCCESS,FAIL_OVER_SPACE
}

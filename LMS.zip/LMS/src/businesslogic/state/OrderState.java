package businesslogic.state;

public enum OrderState {
	QUICK,SIMPLE,CHEAP
}

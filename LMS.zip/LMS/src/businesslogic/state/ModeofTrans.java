package businesslogic.state;

public enum ModeofTrans {
	PLANE,TRAIN,TRUCK
}

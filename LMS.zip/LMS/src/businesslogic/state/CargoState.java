package businesslogic.state;

public enum CargoState {
	LOSE,DAMAGED,WHOLE
}

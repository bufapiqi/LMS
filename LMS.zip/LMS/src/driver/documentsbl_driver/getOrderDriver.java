package driver.documentsbl_driver;

import java.util.ArrayList;

import stub.documentsbl_stub.getOrderBLStub;


public class getOrderDriver {
	public static void main(String[]args){
		getOrderBLStub a=new getOrderBLStub();
		ArrayList<String> list=new ArrayList();
		list=a.getOrder("2015/10/25", "2015/10/26");
		System.out.println(list.get(0));
	}
}

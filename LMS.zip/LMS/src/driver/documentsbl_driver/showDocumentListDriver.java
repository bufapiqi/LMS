package driver.documentsbl_driver;

import java.util.ArrayList;

import stub.documentsbl_stub.showDocumentListBLStub;


public class showDocumentListDriver {
	public static void main(String[]args){
		showDocumentListBLStub a=new showDocumentListBLStub();
		ArrayList<String> list=new ArrayList();
		list=a.showList("��ת��", "2015/10/24", "2015/10/26");
		System.out.println(list.get(0));
	}
}

package driver.documentsbl_driver;

import stub.documentsbl_stub.createDocumentBLStub;
import vo.documentsVO.DocumentVO;


public class createDocumentDriver {
	public static void main(String []args){
		createDocumentBLStub a=new createDocumentBLStub();
		DocumentVO vo=new DocumentVO();
		vo=a.createDocument("0000000001");
		System.out.println(vo.getCode());
	}
}

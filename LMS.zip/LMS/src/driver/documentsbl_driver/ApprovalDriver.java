package driver.documentsbl_driver;

import stub.documentsbl_stub.ApprovalBLStub;
import businesslogicservice.documentsblservice.Approval;

public class ApprovalDriver{
	public static void main(String [] args){
		ApprovalBLStub a=new ApprovalBLStub();
		if(a.approval(true))
			System.out.println("true");
		else{
			System.out.println("false");
		}
	}
}

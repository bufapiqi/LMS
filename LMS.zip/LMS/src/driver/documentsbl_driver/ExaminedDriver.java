package driver.documentsbl_driver;

import stub.documentsbl_stub.ExaminedBLStub;


public class ExaminedDriver {
	public static void main(String[]args){
		ExaminedBLStub a=new ExaminedBLStub();
		System.out.println(a.examined(true));
	}
}

package driver.documentsbl_driver;
import stub.documentsbl_stub.getBufferedInfoBLStub;
import vo.documentsVO.DocumentVO;


public class getBufferedInfoDriver {
	public static void main(String[]args){
		getBufferedInfoBLStub a=new getBufferedInfoBLStub();
		DocumentVO vo=new DocumentVO();
		vo=a.getBufferedInfo("0000000002");;
		System.out.println(vo.getDoName());
	}
}

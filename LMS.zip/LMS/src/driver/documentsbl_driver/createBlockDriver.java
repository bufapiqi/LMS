package driver.documentsbl_driver;

import stub.documentsbl_stub.createBlockBLStub;
import vo.documentsVO.GetOrderVO;


public class createBlockDriver {
	public static void main(String[]args){
		createBlockBLStub a=new createBlockBLStub();
		GetOrderVO VO=new GetOrderVO("0000000001","�ռ���","����","2015/10/26");
		if(!a.createBlock(VO))
			System.out.println("true");
	}
}

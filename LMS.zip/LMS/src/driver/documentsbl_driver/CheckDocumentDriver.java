package driver.documentsbl_driver;

import stub.documentsbl_stub.CheckDocumentBLStub;


public class CheckDocumentDriver {
	public static void main(String[]args){
			CheckDocumentBLStub a=new CheckDocumentBLStub();
			if(!a.checkCenter("000"))
				System.out.println("true");
			if(!a.checkHall("000"))
				System.out.println("true");
			if(!a.checkPlace("M78����"));
				System.out.println("false");
	}
}

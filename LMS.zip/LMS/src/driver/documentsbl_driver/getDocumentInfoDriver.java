package driver.documentsbl_driver;

import stub.documentsbl_stub.getDocumentInfoBLStub;
import vo.documentsVO.DocumentVO;


public class getDocumentInfoDriver {
	public static void main(String[]args){
		getDocumentInfoBLStub a=new getDocumentInfoBLStub();
		DocumentVO vo=new DocumentVO();
		vo=a.getDocumentInfo("0000000003");
		System.out.println(vo.getDoName());
	}
}

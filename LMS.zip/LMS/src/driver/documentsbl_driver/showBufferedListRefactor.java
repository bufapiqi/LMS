package driver.documentsbl_driver;

import java.util.ArrayList;

import stub.documentsbl_stub.showBufferedListBLStub;




public class showBufferedListRefactor {
	public static void main(String []args){
		showBufferedListBLStub a=new showBufferedListBLStub();
		ArrayList<String> list=new ArrayList();
		list=a.showList();
		System.out.println(list.get(0));
		
	}
}

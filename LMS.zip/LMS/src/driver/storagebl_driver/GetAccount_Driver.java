package driver.storagebl_driver;

import stub.storagebl_stub.GetCount_Stub;


public class GetAccount_Driver {
	public static void main(String[] args){
		GetCount_Stub count = new GetCount_Stub();
		System.out.print(count.getCount());
	}
}

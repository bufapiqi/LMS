package driver.storagebl_driver;

import stub.storagebl_stub.RetuenSpace_Stub;


public class RetuenSpace_Driver {
	public static void main(String[] args){
		RetuenSpace_Stub re = new RetuenSpace_Stub();
		System.out.print(re.returnSpace());
	}
}

package driver.storagebl_driver;

import stub.storagebl_stub.usedSpace_Stub;


public class usedSpace_Driver {
	public static void main(String[] args){
		usedSpace_Stub used = new usedSpace_Stub();
		int use [] = new int[3];
		int all [] = new int[3];
		use = used.usedSpaceInf();
		all = used.allSpaceInf();
		
		System.out.print("���ÿռ�Ϊ��");
		for(int i = 0 ; i <3;i++)
			System.out.print(use[i]+"   ");
		System.out.println();
		System.out.print("�ܿռ�Ϊ��");
		for(int i = 0 ; i <3;i++)
			System.out.print(all[i]+"   ");
	}
}

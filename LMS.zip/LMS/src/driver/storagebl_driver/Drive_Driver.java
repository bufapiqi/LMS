package driver.storagebl_driver;

import stub.storagebl_stub.Drive_Stub;

public class Drive_Driver {
	public static void main(String[] args){
		Drive_Stub dri = new Drive_Stub();
		System.out.print(dri.drive(0, 0, 0));
	}
}

package driver.storagebl_driver;

import java.util.ArrayList;

import stub.storagebl_stub.check_inventory_Stub;
import vo.storageVO.InDepotInfVO;
import vo.storageVO.SimpleInDepotInfVO;

public class check_inventory_Driver {
	public static void main(String[] args){
		
		check_inventory_Stub check = new check_inventory_Stub();
		
		ArrayList<SimpleInDepotInfVO> simInfVO = new ArrayList();
		ArrayList<InDepotInfVO> infVO = new ArrayList();
		
		simInfVO = check.check(0, 0);
		for(int i = 0 ; i < simInfVO.size();i++){
			System.out.print(simInfVO.get(i).getInDepotNum()+"  ");
			System.out.print(simInfVO.get(i).getSums()+"  ");
			System.out.print(simInfVO.get(i).getAreaNum()+"  ");
			System.out.print(simInfVO.get(i).getShelvesNum()+"  ");
			System.out.print(simInfVO.get(i).getRowNum()+"  ");
			System.out.println(simInfVO.get(i).getSositionNum());
		}
		
	}
}

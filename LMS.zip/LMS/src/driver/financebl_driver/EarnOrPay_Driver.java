package driver.financebl_driver;

import stub.financebl_stub.EarnOrPay_Stub;



public class EarnOrPay_Driver {
	public static void main(String[] args){
		EarnOrPay_Stub earn = new EarnOrPay_Stub();
		System.out.println(earn.allEarn(null));
		System.out.println(earn.allPay(null));
	}
}

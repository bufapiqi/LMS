package driver.financebl_driver;

import java.util.ArrayList;

import stub.financebl_stub.GetReceivablesBills_Stub;
import vo.documentsVO.ReceiptVO;


public class GetReceivablesBills_Driver {
	public static void main(String[] args){
		GetReceivablesBills_Stub getR = new GetReceivablesBills_Stub();
		ArrayList<ReceiptVO> receip = new ArrayList();
		ArrayList<String> code = new ArrayList();
		receip = getR.getAllReceivables(null);
		for(int i = 0 ; i < receip.size();i++){
			System.out.print(receip.get(i).getDate()+"  ");
			System.out.print(receip.get(i).getFund()+"  ");
			System.out.print(receip.get(i).getName()+"    ");
			code = receip.get(i).getTCode();
			for(int j = 0 ; j < code.size();j++){
				if(j==code.size()-1){
					System.out.println(code.get(j));
				}else{
					System.out.print(code.get(j)+"  ");
				}
			}

		}
	}
}

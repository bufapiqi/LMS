package driver.financebl_driver;

import java.util.ArrayList;

import stub.financebl_stub.ProfitList_Stub;
import vo.financeVO.ProfitVO;


public class ProfitList_Driver {
	public static void main(String[] args){
		ProfitList_Stub pro = new ProfitList_Stub();
		ArrayList<ProfitVO> provo = new ArrayList();
		provo = pro.getProList();
		for(int i = 0 ; i <provo.size();i++){
			System.out.print(provo.get(i).getTotalRevenue()+"       ");
			System.out.print(provo.get(i).getTotalPay()+"      ");
			System.out.println(provo.get(i).getGenerationDate());
		}
	}
}

package driver.financebl_driver;

import java.util.ArrayList;

import stub.financebl_stub.GetAccount_Stub;
import vo.financeVO.AccountVO;

public class GetAccount_Driver {
	public static void main(String[] args){
		GetAccount_Stub  getAcc = new 		GetAccount_Stub();
		ArrayList<AccountVO>  acc = new ArrayList();
		acc= getAcc.getAccount();
		for(int i = 0 ; i <acc.size();i++){
			System.out.print(acc.get(i).getName()+"   ");
			System.out.println(acc.get(i).getSums());
		}
	}
}

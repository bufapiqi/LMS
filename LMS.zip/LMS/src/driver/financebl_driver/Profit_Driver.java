package driver.financebl_driver;

import stub.financebl_stub.Profit_Stub;


public class Profit_Driver {
	public static void main(String[] args){
		Profit_Stub pro = new Profit_Stub();
		System.out.print(pro.Profit(12354.95, 6594466.58));
	}
}

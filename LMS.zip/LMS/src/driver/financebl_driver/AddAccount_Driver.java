package driver.financebl_driver;

import stub.financebl_stub.AddAccount_Stub;
import vo.financeVO.AccountVO;

public class AddAccount_Driver {
	public static void main(String[] args){
		AddAccount_Stub acc;
		acc = new AddAccount_Stub();
		AccountVO vo = acc.addAccount("�°���",526423154);
		System.out.println(vo.getName());
		System.out.println(vo.getSums());
	}
}

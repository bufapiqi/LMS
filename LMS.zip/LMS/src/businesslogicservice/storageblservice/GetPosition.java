package businesslogicservice.storageblservice;

import vo.storageVO.DepotVO;

public interface GetPosition {
	
	public DepotVO getPOsition();
	
}

package vo.documentsVO;


public class YDispatchVO  extends DocumentVO{
	private String date;//�ɼ�����
	private String code;//�ɼ������
	private String doName;//������
	private String name;//�ɼ����Ա����
	
	public YDispatchVO(String date, String code, String doName, String name) {
		super();
		this.date = date;
		this.code = code;
		this.doName = doName;
		this.name = name;
	}


	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDoName() {
		return doName;
	}


	public void setDoName(String doName) {
		this.doName = doName;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

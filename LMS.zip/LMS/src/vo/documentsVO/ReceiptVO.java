package vo.documentsVO;


import java.util.ArrayList;

public class ReceiptVO  extends DocumentVO{
	private String code;//�տ���
	private String doName;//������
	private String date;//�տ�����

	private double fund;//�տ���
	private String name;//���Ա����
	private ArrayList<String> TCode;//���ж����������
	
	public ReceiptVO(String code, String doName, String date, double fund,
			String name, ArrayList<String> tCode) {
		super();
		this.code = code;
		this.doName = doName;
		this.date = date;
		this.fund = fund;
		this.name = name;
		TCode = tCode;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDoName() {
		return doName;
	}
	public void setDoName(String doName) {
		this.doName = doName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getFund() {
		return fund;
	}
	public void setFund(double fund) {
		this.fund = fund;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<String> getTCode() {
		return TCode;
	}
	public void setTCode(ArrayList<String>TCode) {
		this.TCode = TCode;
	}
}

package stub.financebl_stub;

import java.util.ArrayList;

import vo.documentsVO.ReceiptVO;
import businesslogicservice.financeblservice.GetAllcount;

public class GetAllcount_Stub implements GetAllcount{

	GetReceivablesBills_Stub get;
	@Override
	public double getAllciunt(ArrayList<ReceiptVO> vo) {
		// TODO �Զ����ɵķ������
		double result =  0;
		get = new GetReceivablesBills_Stub();
		ArrayList<ReceiptVO> po = get.getAllReceivables("da");
		for(int i = 0 ; i <po.size();i++){
			result = result + po.get(i).getFund();
		}
		return result;
	}

}

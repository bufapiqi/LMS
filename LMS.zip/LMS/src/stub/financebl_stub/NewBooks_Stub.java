package stub.financebl_stub;


import vo.financeVO.BooksVO;
import businesslogicservice.financeblservice.NewBooks;;
public class NewBooks_Stub implements NewBooks{

	BooksVO newVO ;
	@Override
	public BooksVO newBooks(BooksVO vo) {
		// TODO �Զ����ɵķ������
		newVO = new BooksVO(vo.getArrOrg(), vo.getPerson(), vo.getVehicle(), vo.getAccount(), vo.getInBills());
		
		return newVO;
	}
	
}

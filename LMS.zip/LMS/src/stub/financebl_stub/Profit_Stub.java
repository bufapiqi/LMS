package stub.financebl_stub;

import businesslogicservice.financeblservice.Profit;

public class Profit_Stub implements Profit{


	@Override
	public double Profit(double Pay, double Receivables) {
		// TODO Auto-generated method stub
		return Receivables-Pay;
	}

}

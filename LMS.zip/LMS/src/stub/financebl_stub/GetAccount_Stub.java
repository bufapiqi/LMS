package stub.financebl_stub;
import java.util.ArrayList;

import vo.financeVO.AccountVO;
import businesslogicservice.financeblservice.GetAccount;

public class GetAccount_Stub implements GetAccount{

	ArrayList<AccountVO>  account  = new ArrayList();
	@Override
	public ArrayList<AccountVO> getAccount() {
		// TODO �Զ����ɵķ������
		
		AccountVO a1 = new AccountVO("���",100000);
		AccountVO a2 = new AccountVO("�Ÿ�",10254);
		AccountVO a3 = new AccountVO("����",256.32);
		AccountVO a4 = new AccountVO("����",54651.58);
		AccountVO a5 = new AccountVO("����",546.587);
		AccountVO a6 = new AccountVO("����",598756.4562);
		AccountVO a7 = new AccountVO("�",55521);
		account.add(a1);
		account.add(a2);
		account.add(a3);
		account.add(a4);
		account.add(a5);
		account.add(a6);
		account.add(a7);
		return account;
	}

}

package stub.financebl_stub;

import vo.financeVO.AccountVO;
import businesslogicservice.financeblservice.AddAccount;

public class AddAccount_Stub implements AddAccount{

	AccountVO ap ;
	@Override
	public AccountVO addAccount(String name, double money) {
		// TODO �Զ����ɵķ������
		ap = new AccountVO(name,money);
		return ap;
	}
	
}

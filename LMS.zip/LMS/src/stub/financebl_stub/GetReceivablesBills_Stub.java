package stub.financebl_stub;

import java.util.ArrayList;

import vo.documentsVO.ReceiptVO;
import businesslogicservice.financeblservice.*;

public class GetReceivablesBills_Stub implements GetReceivablesBills {

	ArrayList<ReceiptVO> receiptList = new ArrayList();
	ArrayList<String> code = new ArrayList();
	String c1 = "02156401",c2="02156402",c3="02156403",c4="02156404";
	@Override
	public ArrayList<ReceiptVO> getReceivables(String selling, String date) {
		// TODO �Զ����ɵķ������
		code.add(c1);
		code.add(c2);
		code.add(c3);
		code.add(c4);
		ReceiptVO r1 = new ReceiptVO("0000001","�տ","2015/05/06", 25361, "�¶�ķ", code);
		ReceiptVO r2 = new ReceiptVO("0000002","�տ","2015/05/07", 96841, "����ķ", code);
		ReceiptVO r3 = new ReceiptVO("0000003","�տ","2015/05/08", 15675, "�ղ���", code);
		ReceiptVO r4 = new ReceiptVO("0000004","�տ","2015/05/09", 58462, "������", code);
		receiptList.add(r1);
		receiptList.add(r2);
		receiptList.add(r3);
		receiptList.add(r4);
		
		return receiptList;
	}

	@Override
	public ArrayList<ReceiptVO> getAllReceivables(String selling) {
		// TODO �Զ����ɵķ������
		code.add(c1);
		code.add(c2);
		code.add(c3);
		code.add(c4);
		ReceiptVO r1 = new ReceiptVO("0000001","�տ","2015/05/06", 25361, "�¶�ķ", code);
		ReceiptVO r2 = new ReceiptVO("0000002","�տ","2015/05/07", 96841, "����ķ", code);
		ReceiptVO r3 = new ReceiptVO("0000003","�տ","2015/05/08", 15675, "�ղ���", code);
		ReceiptVO r4 = new ReceiptVO("0000004","�տ","2015/05/09", 58462, "������", code);
		receiptList.add(r1);
		receiptList.add(r2);
		receiptList.add(r3);
		receiptList.add(r4);
		return receiptList;
	}

	@Override
	public ArrayList<ReceiptVO> getSomeReceivables(String selling,
			String start, String end) {
		// TODO �Զ����ɵķ������
		code.add(c1);
		code.add(c2);
		code.add(c3);
		code.add(c4);
		ReceiptVO r1 = new ReceiptVO("0000001","�տ","2015/05/06", 25361, "�¶�ķ", code);
		ReceiptVO r2 = new ReceiptVO("0000002","�տ","2015/05/07", 96841, "����ķ", code);
		ReceiptVO r3 = new ReceiptVO("0000003","�տ","2015/05/08", 15675, "�ղ���", code);
		ReceiptVO r4 = new ReceiptVO("0000004","�տ","2015/05/09", 58462, "������", code);
		receiptList.add(r1);
		receiptList.add(r2);
		receiptList.add(r3);
		receiptList.add(r4);
		return receiptList;
	}
	
}

package stub.financebl_stub;

import java.util.ArrayList;

import vo.financeVO.ProfitVO;
import businesslogicservice.financeblservice.ProfitList;

public class ProfitList_Stub implements ProfitList{

	ArrayList<ProfitVO> provo = new ArrayList();
	ProfitVO p1 = new ProfitVO(52623554, 2648764, "2015/5/20");
	ProfitVO p2 = new ProfitVO(695845, 12549.5, "2015/6/20");
	ProfitVO p3 = new ProfitVO(975684.68, 345987, "2015/6/29");
	ProfitVO p4 = new ProfitVO(1000000, 584522, "2015/7/15");
	ProfitVO p5 = new ProfitVO(3695775, 687453, "2015/8/20");
	ProfitVO p6 = new ProfitVO(98754624, 321546, "2015/9/20");
	ProfitVO p7 = new ProfitVO(98756481, 369854, "2015/10/20");
	ProfitVO p8 = new ProfitVO(58974562, 264876, "2015/11/20");
	@Override
	public ArrayList<ProfitVO> getProList() {
		// TODO �Զ����ɵķ������
		provo.add(p1);
		provo.add(p2);
		provo.add(p3);
		provo.add(p4);
		provo.add(p5);
		provo.add(p6);
		provo.add(p7);
		provo.add(p8);
		return provo;
	}
}

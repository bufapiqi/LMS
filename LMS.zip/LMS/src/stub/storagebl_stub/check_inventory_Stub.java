package stub.storagebl_stub;
import java.util.ArrayList;

import vo.storageVO.InDepotInfVO;
import vo.storageVO.SimpleInDepotInfVO;
import businesslogicservice.storageblservice.*;
public class check_inventory_Stub implements check_inventory{

	ArrayList<SimpleInDepotInfVO> simInfVO = new ArrayList();
	ArrayList<InDepotInfVO> infVO = new ArrayList();
	@Override
	public ArrayList<SimpleInDepotInfVO> check(int start, int end) {
		// TODO �Զ����ɵķ������
		SimpleInDepotInfVO s1 =new SimpleInDepotInfVO("25146214", 256.2, "01", "05", "08", "15");
		SimpleInDepotInfVO s2 =new SimpleInDepotInfVO("02154621", 326.1, "01", "06", "10", "03");
		SimpleInDepotInfVO s3 =new SimpleInDepotInfVO("25146214", 11.2, "02", "04", "09", "05");
		SimpleInDepotInfVO s4 =new SimpleInDepotInfVO("25146214", 15.6, "03", "03", "05", "25");
		SimpleInDepotInfVO s5 =new SimpleInDepotInfVO("25146214", 32.3, "04", "02", "04", "19");
		SimpleInDepotInfVO s6 =new SimpleInDepotInfVO("25146214", 59.8, "05", "01", "03", "03");
		simInfVO.add(s1);
		simInfVO.add(s2);
		simInfVO.add(s3);
		simInfVO.add(s4);
		simInfVO.add(s5);
		simInfVO.add(s6);
		return simInfVO;
	}

	@Override
	public ArrayList<InDepotInfVO> inventory() {
		// TODO �Զ����ɵķ������
		InDepotInfVO i1 = new InDepotInfVO("010526416", "2015/10/17", "�Ͼ�", "01", "05", "08", "15");
		InDepotInfVO i2 = new InDepotInfVO("010526417", "2015/10/17", "�Ͼ�", "01", "05", "08", "16");
		InDepotInfVO i3 = new InDepotInfVO("010526418", "2015/10/15", "�Ͼ�", "01", "05", "08", "17");
		InDepotInfVO i4 = new InDepotInfVO("010526419", "2015/10/16", "�Ͼ�", "01", "05", "08", "18");
		
		infVO.add(i1);
		infVO.add(i2);
		infVO.add(i3);
		infVO.add(i4);
		
		return infVO;
	}
	
}

package stub.storagebl_stub;

import businesslogic.state.ResultMessage;
import businesslogicservice.storageblservice.Drive;

public class Drive_Stub implements Drive{

	ResultMessage message;
	@Override
	public ResultMessage drive(int shipping, int trains, int motor) {
		// TODO �Զ����ɵķ������
		return message.SUCCESS;
	}

}

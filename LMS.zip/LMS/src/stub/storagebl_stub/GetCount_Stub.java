package stub.storagebl_stub;

import businesslogicservice.storageblservice.GetCount;

public class GetCount_Stub implements GetCount{

	@Override
	public int getCount() {
		// TODO �Զ����ɵķ������
		return 1000;
	}

}

package stub.storagebl_stub;

import businesslogic.state.ResultMessage;
import businesslogicservice.storageblservice.RetuenSpace;

public class RetuenSpace_Stub implements RetuenSpace{

	ResultMessage message;
	@Override
	public ResultMessage returnSpace() {
		// TODO �Զ����ɵķ������
		return message.SUCCESS;
	}

}

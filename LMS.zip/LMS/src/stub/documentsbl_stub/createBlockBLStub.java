package stub.documentsbl_stub;

import vo.documentsVO.DocumentVO;
import businesslogicservice.documentsblservice.createBlock;

public class createBlockBLStub implements createBlock{

	@Override
	public boolean createBlock(DocumentVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

}

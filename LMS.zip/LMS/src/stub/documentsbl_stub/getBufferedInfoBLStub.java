package stub.documentsbl_stub;

import vo.documentsVO.DocumentVO;
import vo.documentsVO.GetOrderVO;
import businesslogicservice.documentsblservice.getBufferedInfo;

public class getBufferedInfoBLStub implements getBufferedInfo{

	@Override
	public DocumentVO getBufferedInfo(String code) {
		// TODO Auto-generated method stub
		GetOrderVO vo=new GetOrderVO("0000000002","�ռ���","Ҷ����","2015/10/26");
		return vo;
	}
	
}

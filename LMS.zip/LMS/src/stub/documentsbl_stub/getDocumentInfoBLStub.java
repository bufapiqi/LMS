package stub.documentsbl_stub;
import vo.documentsVO.DocumentVO;
import vo.documentsVO.GetOrderVO;
import businesslogicservice.documentsblservice.getDocumentInfo;


public class getDocumentInfoBLStub implements getDocumentInfo{

	@Override
	public DocumentVO getDocumentInfo(String code) {
		// TODO Auto-generated method stub
		GetOrderVO vo=new GetOrderVO("0000000012","�ռ���","������","2015/10/26");
		return vo;
	}

}

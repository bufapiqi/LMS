package stub.documentsbl_stub;

import java.util.ArrayList;

import businesslogicservice.documentsblservice.showBufferedList;

public class showBufferedListBLStub implements showBufferedList{

	@Override
	public ArrayList<String> showList() {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList();
		list.add("0000000012�տ");
		list.add("0000000013���");
		return list;
	}

}

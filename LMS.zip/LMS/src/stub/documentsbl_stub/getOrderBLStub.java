package stub.documentsbl_stub;

import java.util.ArrayList;

import businesslogicservice.documentsblservice.getOrder;

public class getOrderBLStub implements getOrder{

	@Override
	public ArrayList<String> getOrder(String startTime, String endTime) {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList();
		list.add("0000000002");
		list.add("0000000032");
		list.add("0000000012");
		list.add("100");
		return list;
	}

}

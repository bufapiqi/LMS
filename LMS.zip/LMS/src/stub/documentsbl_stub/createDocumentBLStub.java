package stub.documentsbl_stub;

import vo.documentsVO.DocumentVO;
import vo.documentsVO.GetOrderVO;
import businesslogicservice.documentsblservice.createDocument;

public class createDocumentBLStub implements createDocument{

	@Override
	public DocumentVO createDocument(String doName) {
		// TODO Auto-generated method stub
		GetOrderVO vo=new GetOrderVO("0000000001","�ܿ���","getOrder","2015/10/26");
		return vo;
	}

}

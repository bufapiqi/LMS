package stub.documentsbl_stub;

import java.util.ArrayList;

import businesslogicservice.documentsblservice.showDocumentList;

public class showDocumentListBLStub implements showDocumentList{

	@Override
	public ArrayList<String> showList(String doName, String startTime,
			String endTime) {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList();
		list.add("0010010001��ת��");
		list.add("0020030002��ת��");
		return list;
	}

}

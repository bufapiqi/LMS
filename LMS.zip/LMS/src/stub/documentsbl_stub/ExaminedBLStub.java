package stub.documentsbl_stub;

import businesslogicservice.documentsblservice.Examined;

public class ExaminedBLStub implements Examined{

	@Override
	public boolean examined(boolean examined) {
		// TODO Auto-generated method stub
		return false;
	}

}

package stub.documentsbl_stub;

import businesslogicservice.documentsblservice.CheckDocument;

public class CheckDocumentBLStub implements CheckDocument{

	@Override
	public boolean checkHall(String codeNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkCenter(String codeNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkPlace(String city) {
		// TODO Auto-generated method stub
		return false;
	}

}

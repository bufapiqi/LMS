package stub.documentsbl_stub;

import businesslogicservice.documentsblservice.Approval;

public class ApprovalBLStub implements Approval{

	@Override
	public boolean approval(boolean approved) {
		// TODO Auto-generated method stub
		return true;
	}
	
}
